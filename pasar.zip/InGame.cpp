#pragma once

#include <sstream>
#include "InGame.h"
#include "MenuMuerte.h"
#include "MenuFinal.h"
#include "Menu.h"
#include <iostream>

namespace Alfheim
{
   
       InGame::InGame(DatosJuegoRef datos) : _datos(datos)
       {
           
           mapa = new Mapa();
           mapa->leerMapa();
           
           
            
            
       }
        
        void InGame::Init()
        {
            personaje = new Personaje(_datos);
           
            hud = new Hud(_datos);
            hud->SetPuntos(personaje->getPuntos()); 
            hud->SetMana(personaje->getMana());
            hud->SetVida(personaje->getVida());
               
//            interfaz = new Interfaz(_datos);
            /* POCION DE PRUEBA */
          pocPrueba = new Pocion(_datos, 32, 32, 1);
            
          
            
            
            
            
            
        }
        
        void InGame::ManejarEventos()
        {
           
                     
            sf::Event event;
            while(_datos->ventana.pollEvent(event))
            {
                
            switch(event.type){
                
                case sf::Event::Closed:
                    _datos->ventana.close();
                break;
                
                case sf::Event::KeyPressed:
                    if(event.key.code == sf::Keyboard::P){
                        // prueba puntos para ver si actualiza
                        personaje->setPuntos(100);
                    
                    }
                    if(event.key.code == sf::Keyboard::M){
                        // prueba pantalla de muerte
                        personaje->setVida(0);
                    
                    }
                    if(event.key.code == sf::Keyboard::F){
                        // prueba pantalla de fin de partida
                        _datos->state.AddEJ(JuegoStateRef(new MenuFinal(_datos)),true);
           
                    
                    }
                   
                    if(event.key.code == sf::Keyboard::Right){
                            if(pasos.getElapsedTime().asSeconds() > 0.1f){
                                if(xs < 8) xs++;
                                if(xs > 7) xs = 4;
                                if(ys < 4) ys++;                                
                                if(ys > 3) ys = 0;
                                pasos.restart();
                            }
                            personaje->Girar(1,xs,ys);
                            
                            
                            /* PUNTOS DE PERSONAJE PRUEBA*/
                            // ganar puntos y actualizar en pantalla
                           // personaje->setPuntos(personaje->getPuntos()+1);
                            // _txtPuntos.setString("Puntos: "+std::to_string(personaje->getPuntos()));
           
                            //std::cout << personaje->getPuntos()<< std::endl;
                    }
                    
                     if(event.key.code == sf::Keyboard::Left){
                            if(pasos.getElapsedTime().asSeconds() > 0.07f){
                                  if(xs < 8) xs++;
                                  if(ys < 4) ys++;
                                  if(xs > 7) xs = 4;
                                  if(ys > 3) ys = 0;
                                  pasos.restart();
                            }
                            personaje->Girar(2,xs,ys);
                     }
                        
                     if(event.key.code ==  sf::Keyboard::Up){
                            if(pasos.getElapsedTime().asSeconds() > 0.07f){
                                  if(xu < 4) xu++;
                                  if(yu < 8) yu++;
                                  if(xu > 3) xu = 0;
                                  if(yu > 7) yu = 4;
                                  pasos.restart();
                            }
                            personaje->Girar(3,xu,yu);
                     }
                        
                       if(event.key.code ==  sf::Keyboard::Down){
                            if(pasos.getElapsedTime().asSeconds() > 0.07f){
                                  if(xd < 4) xd++;
                                  if(yd < 4) yd++; 
                                  if(xd > 3) xd = 0;
                                  if(yd > 3) yd = 0;
                                  pasos.restart();
                            }
                            personaje->Girar(4,xd,yd);
                       }
                        
                       if(event.key.code == sf::Keyboard::Escape)
                            _datos->ventana.close();
                    
                    
                    
                    break;
            }        
            }
        }
        void InGame::Update(float dt)
        {
            if(_clock.getElapsedTime().asSeconds() > 1.0){
                  // std::cout << "updatin "<< std::endl;
            hud->SetPuntos(personaje->getPuntos()); 
            hud->SetMana(personaje->getMana());
            hud->SetVida(personaje->getVida());
            
            /*  CAMBIO ESTADOS DE MENU */
            if(personaje->compruebaMuerte()){
                _datos->state.AddEJ(JuegoStateRef(new MenuMuerte(_datos)),true);
            }
                   
            }
        }
        
        void InGame::Render(float dt)
        {
            _datos->ventana.clear();
             mapa->dibujarMapa(_datos->ventana);
             
            
            
            
            
            personaje->Pintar(); 
            std::cout << "pinto pj "<< std::endl;
            pocPrueba->Pintar();
            _datos->ventana.draw(hud->GetTxtVida());
            _datos->ventana.draw(hud->GetTxtMana());
            _datos->ventana.draw(hud->GetTxtPuntos());
            
            _datos->ventana.display();
            
           // std::cout << "rendering "<< std::endl;
        }
        
   
}